#ifndef DDOT_H
#define DDOT_H
int ddot (const int n, const float * const x, const float * const y, float * const result);
#endif
